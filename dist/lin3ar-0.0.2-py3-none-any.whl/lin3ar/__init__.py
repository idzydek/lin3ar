def hello():
    return "lin3ar placeholder"